/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_exit.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nettalha <nettalha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/31 20:15:34 by nettalha          #+#    #+#             */
/*   Updated: 2023/08/27 19:10:19 by nettalha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	ft_exit(t_game *game)
{
	int	i;

	i = 0;
	while (i < count_map_lines(game->map))
		free(game->map[i++]);
	free(game->map);
	exit(0);
}
