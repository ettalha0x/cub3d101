/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fill_map_arr.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nettalha <nettalha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/12 11:26:31 by nettalha          #+#    #+#             */
/*   Updated: 2023/08/26 19:52:58 by nettalha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"
int only_sp(char *s)
{
	int	i;

	i = 0;
	while (s[i])
	{
		if (s[i] != ' ' && s[i] != '\n' && s[i] != '\t')
			return (0);
		i++;
	}
	return 1;
}

void	read_textures(char **textures, int fd)
{
	int	i;

	i = 0;
	textures[i] = get_next_line(fd);
	while (textures[i] && i < 6)
	{
		if (!only_sp(textures[i]))
			i++;
		textures[i] = get_next_line(fd);
	}
	textures[i + 1] = NULL;
}

void	read_map(char **map, int fd)
{
	int	i;

	i = 0;
	map[i] = get_next_line(fd);
	while (map[i])
	{
		if (!only_sp(map[i]))
			i++;
		map[i] = get_next_line(fd);
	}
}

char	**fill_map_arr(t_game	*game, char *file)
{
	int		len;
	int		fd;
	int		i;


	i = 0;
	if (!check_map_name(file))
	{
		printf("file name error");
		exit(0);
	}
	len = count_file_lines(file);
	game->map = malloc(sizeof(char *) * (len + 1));
	game->textures = malloc(sizeof(char *) * 7);
	game->map[len] = NULL;
	if (!game->map)
		return (0);
	fd = open(file, O_RDONLY);
	read_textures(game->textures, fd);
	read_map(game->map, fd);
	printf("************* map *************\n");
	i = 0;
	while (game->map[i])
	{
		printf("*");
		printf("%s", game->map[i++]);
		// printf("*");
	}
	printf("\n");
	printf("************* textures *************\n");
	i = 0;
	while (game->textures[i])
		printf("%s", game->textures[i++]);
	return (game->map);
}
