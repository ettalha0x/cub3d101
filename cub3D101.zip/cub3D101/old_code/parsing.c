/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nettalha <nettalha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/12 11:16:51 by nettalha          #+#    #+#             */
/*   Updated: 2023/08/27 19:13:19 by nettalha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

int	parser(t_game *g)
{
	if (check_map_args(g) && check_map(g) && check_map_in(g) && check_player(g))
		return (1);
	return (0);
}
