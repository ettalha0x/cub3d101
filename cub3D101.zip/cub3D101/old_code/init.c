/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nettalha <nettalha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/25 16:26:33 by nettalha          #+#    #+#             */
/*   Updated: 2023/09/04 16:10:54 by nettalha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

char *get_tall_line(char **map)
{
    int index = 0;
    int len= 0;

    int curr_index = 0;
    while (map[curr_index] != NULL)
	{
        int curr_len = 0;
        while (map[curr_index][curr_len] != '\0')
            curr_len++;

        if (curr_len > len)
		{
            len = curr_len;
            index = curr_index;
        }
        curr_index++;
    }
    return map[index];
}

void	game_init(t_game *game)
{
	game->map_w = (ft_strlen(get_tall_line(game->map)) - 1) * SQUAR_SIZE;
	game->map_h = count_map_lines(game->map) * SQUAR_SIZE;
    game->mlx = mlx_init(game->map_w, game->map_h, "Cub3D", true);
    game->img = mlx_new_image(game->mlx, game->map_w, game->map_h);
	mlx_image_to_window(game->mlx, game->img, 0, 0);
}

void	vars_init(t_game *game)
{
    if(game->p_pos == 'N')
        game->angle = 90;
    else if(game->p_pos == 'W')
        game->angle = 180;
    else if(game->p_pos == 'S')
        game->angle = 270;
    else if(game->p_pos == 'E')
        game->angle = 360;
    else
        printf("error to save player position !\n");
}