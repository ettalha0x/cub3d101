/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cub3d.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nettalha <nettalha@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/12 11:24:37 by nettalha          #+#    #+#             */
/*   Updated: 2023/01/01 14:59:26 by nettalha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CUB3D_H
# define CUB3D_H

# include <stdio.h>
# include <math.h>
# include "./libft/libft.h"
# include "./gnl/get_next_line.h"
# include "/Users/nettalha/MLX42/include/MLX42/MLX42.h"

# define SQUAR_SIZE	50
# define MIN	0.2

typedef struct s_player
{
	float	x;
	float	y;
}t_player;

typedef struct s_game
{
	mlx_t		*mlx;
	mlx_image_t	*img;
	char		**map;
	int32_t		map_w;
	int32_t		map_h;
	char		**textures;
	char		*we_path;
	char		*so_path;
	char		*no_path;
	char		*ea_path;
	char		*f_color;
	char		*c_color;
	char		p_pos;
	int			n_player;
	t_player	player;	
	float		angle;
	float		vue_angle;
}	t_game;


typedef struct s_vec
{
	float	x;
	float	y;
}t_vec;

typedef struct s_pix
{
	int	x;
	int	y;
}t_pix;

int		check_map_name(char *name);
int		check_map_in(t_game *g);
int		check_player(t_game *g);
int		parser(t_game *g);
int		check_map_args(t_game *g);
void	check_textures(t_game *g, char	**s, char **dire, int i);
void	check_colors(t_game *g, char **s, int i);
int		count_file_lines(char *file);
int		count_map_lines(char **map);
int		check_map(t_game *g);
char	**fill_map_arr(t_game *game, char *file);
void	read_textures(char **textures, int fd);
void	read_map(char **map, int fd);
void	ft_exit(t_game *game);
void	draw_line(t_game *g, t_vec p1, t_vec p2, int color);
void	draw_vue_angle(t_game *g, t_vec p1, t_vec p2);
void	draw_player(t_game *g, int x, int y);
void	draw_back(t_game *g);
void	draw_space(t_game *g, int x, int y);
void	draw_wall(t_game *g, int x, int y);
void	draw_grid(t_game *g);
void	ft_build(t_game *g);
void	ft_rebuild(t_game *g);
void	game_init(t_game *game);
void	vars_init(t_game *game);
void	move_u(t_game *game, t_vec v);
void	move_d(t_game *game, t_vec v);
void	move_r(t_game *game, t_vec v);
void	move_l(t_game *game, t_vec v);
void	move_player(t_game *game);
void	key_hook(void *void_game);
int		close_win(t_game *game);
void	ft_free(char **s);
float	get_distance(t_player p1, t_vec p2);
void	draw_3d_wall(t_game *g, float distance, int i);
void	draw_column(t_game *g, t_vec p, float height);
void	draw_SkyAndFloor(t_game *g);
void	find_player(t_game *g, t_vec p1, t_vec p2);
void	draw_fov(t_game *g, t_vec p1, t_vec p2);
float	get_ray_distance(t_game *g, t_vec p1, t_vec p2);

#endif
