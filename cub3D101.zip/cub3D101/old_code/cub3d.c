/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cub3d.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nettalha <nettalha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/07 15:23:58 by nettalha          #+#    #+#             */
/*   Updated: 2023/09/02 10:55:23 by nettalha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

int	main(int argc, char **argv)
{
	t_game	mlx;

	if (argc == 2)
	{
		vars_init(&mlx);
		mlx.map = fill_map_arr(&mlx, argv[1]);
		if (!parser(&mlx))
		{
			printf("Error! map is wrong\n");
			ft_exit(&mlx);
		}
		ft_free(mlx.map);
		mlx.map = fill_map_arr(&mlx, argv[1]);
		game_init(&mlx);
		ft_build(&mlx);
		mlx_loop_hook(mlx.mlx, &key_hook, &mlx);
		mlx_loop(mlx.mlx);
	}
	else
	{
		printf("Error : invalid syntax\n");
		exit(EXIT_FAILURE);
	}
}
