/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nettalha <nettalha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/14 15:02:42 by nettalha          #+#    #+#             */
/*   Updated: 2023/09/16 17:35:14 by nettalha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"


void	ft_free(char **s)
{
	int	i;

	if (!s)
		return ;
	else
	{
		i = 0;
		while (s[i])
		{
			free(s[i]);
			i++;
		}
	}
	free(s);
}

// float	get_distance(t_player p1, t_vec p2)
// {
// 	float	distance;
	
// 	distance = sqrt((p2.x - p1.x) * (p2.x - p1.x) + (p2.y - p1.y) * (p2.y - p1.y));
// 	return (distance);
// }


// void	ft_refactor(t_game *g)
// {
// 	int	i;
// 	int	j;

// 	i = 0;
// 	while (g->map[i])
// 	{
// 		j = 0;
// 		while (g->map[i][j])
// 		{
// 			if (g->map[i][j] == '0' && g->map[i + 1][j] == '1' && g->map[i - 1][j] == '1' && g->map[i][j + 1] == '1' && g->map[i][j - 1] == '1')
// 				g->map[i][j] = 'X';
// 			j++;
// 		}
// 		i++;
// 	}
// 	printf("************* map *************\n");
// 	i = 0;
// 	while (g->map[i])
// 	{
// 		printf("*");
// 		printf("%s", g->map[i++]);
// 		// printf("*");
// 	}
// }