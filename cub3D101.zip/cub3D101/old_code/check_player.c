/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_player.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nettalha <nettalha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/23 18:18:47 by nettalha          #+#    #+#             */
/*   Updated: 2023/08/03 12:22:41 by nettalha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

int	check_player(t_game *g)
{
	int	i;
	int	j;

	i = 0;
	while (g->map[i])
	{
		j = 0;
		while (g->map[i][j])
		{
			if (g->map[i][j] == 'N' || g->map[i][j] == 'S' || g->map[i][j] == 'E' || g->map[i][j] == 'W')
			{
				g->p_pos = g->map[i][j];
				g->n_player++;
			}
			j++;
		}
		i++;
	}
	if (g->n_player != 1)
	{
		printf("nb: |%d|\n", g->n_player);
		printf("player error !\n");
		return (0);
	}
	return (1);
}
