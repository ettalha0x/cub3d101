/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_textures.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nettalha <nettalha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/12 11:23:37 by nettalha          #+#    #+#             */
/*   Updated: 2023/08/23 10:07:36 by nettalha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

int	check_rgb(char *s1, char *s2, char *s3)
{
	if ((ft_atoi(s1) >= 0 && ft_atoi(s1) <= 255)
		&& (ft_atoi(s2) >= 0 && ft_atoi(s2) <= 255)
		&& (ft_atoi(s3) >= 0 && ft_atoi(s3) <= 255))
		return (1);
	return(0);
}

void	save_textures(t_game *g, char *texture)
{
	char	**s;

	s = ft_split(texture, ' ');
	if(!ft_strcmp(s[0], "WE"))
		g->we_path = ft_strdup(ft_strtrim2(s[1]));
	else if(!ft_strcmp(s[0], "SO"))
		g->so_path = ft_strdup(ft_strtrim2(s[1]));
	else if(!ft_strcmp(s[0], "NO"))
		g->no_path = ft_strdup(ft_strtrim2(s[1]));
	else if(!ft_strcmp(s[0], "EA"))
		g->ea_path = ft_strdup(ft_strtrim2(s[1]));
	else
		printf("error saving texture !\n");
	ft_free(s);
}
void	save_colors(t_game *g, char *color)
{
	char	**s;

	s = ft_split(color, ' ');
	if(!ft_strcmp(s[0], "F"))
		g->f_color = ft_strdup(ft_strtrim2(s[1]));
	else if(!ft_strcmp(s[0], "C"))
		g->c_color = ft_strdup(ft_strtrim2(s[1]));
	else
		printf("error saving color !\n");
	ft_free(s);
}

void	check_textures(t_game *g, char	**s, char **dire, int i)
{
	int j;
	
	j = 0;
	while (dire[j])
	{
		if (ft_strnstr(g->textures[i], dire[j], ft_strlen(g->textures[i])))
		{
			s = ft_split(g->textures[i], ' ');
			if (s[1][ft_strlen(s[1]) - 1] == '\n')
				s[1] = ft_strtrim(s[1], "\n");
			if (!ft_strcmp(s[0], dire[j]) && open(s[1], O_RDONLY) != -1 && (s[2] == NULL || s[2][0] == '\n'))
			{
				//save textures paths here
				save_textures(g, g->textures[i]);
				printf("%s path is correct\n", dire[j]);
				break ;
			}
			else
				printf("texture error\n");
			ft_free(s);
		}
		j++;
	}
}
void	check_colors(t_game *g, char **s, int i)
{
	if (ft_strnstr(g->textures[i], "F", ft_strlen(g->textures[i])) || ft_strnstr(g->textures[i], "C", ft_strlen(g->textures[i])))
	{
		s = ft_split(g->textures[i], ' ');
		if (s[0][0] == 'F' || s[0][0] == 'C')
		{
			printf("%c color is correct\n", s[0][0]);
			s = ft_split(s[1], ',');
			if (check_rgb(s[0], s[1], s[2]) && (s[3] == NULL || s[3][0] == '\n'))
			{
				//save colors here
				save_colors(g, g->textures[i]);
				printf("rgb is correct\n");
			}
			else
				printf("rgb error\n");
		}
		else
			printf("colors error\n");
		ft_free(s);
	}
}

int	check_map_args(t_game *g)
{
	int		i;
	char	**s;
	char	**directions;

	i = 0;
	s = NULL;
	directions = ft_split("NO SO WE EA", ' ');
	while (g->textures[i])
	{
		check_textures(g, s, directions, i);
		check_colors(g, s, i);
		i++;
	}
	ft_free(directions);
	// printf("%s\n", g->we_path);
	// printf("%s\n", g->ea_path);
	// printf("%s\n", g->so_path);
	// printf("%s\n", g->no_path);
	// printf("%s\n", g->f_color);
	// printf("%s\n", g->c_color);
	return (1);
}
