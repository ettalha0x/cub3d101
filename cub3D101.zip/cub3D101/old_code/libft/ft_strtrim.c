/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nettalha <nettalha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/05 17:05:06 by nettalha          #+#    #+#             */
/*   Updated: 2023/08/31 11:49:34 by nettalha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strtrim(char const *s1, char const *set)
{
	char			*str;
	size_t			len;

	if (!s1 || !set)
		return (NULL);
	while (*s1 != '\0' && ft_strchr(set, *s1))
	{
		s1++;
	}
	len = ft_strlen(s1);
	while (len && ft_strchr(set, s1[len]))
		len--;
	str = ft_substr(s1, 0, len + 1);
	return (str);
}

int	isspace(int c)
{
	if (c == ' ' || c == '\t' || c == '\n' 
		|| c == '\r' || c == '\v' || c == '\f')
		return (c);
	return (0);
}

char	*ft_strtrim2(char const *s1)
{
	char			*str;
	size_t			len;

	if (!s1)
		return (NULL);
	while (*s1 != '\0' && isspace(*s1))
		s1++;
	len = ft_strlen(s1);
	if (len > 0)
	{
		while (len && isspace(s1[len - 1]))
			len--;
	}
	str = ft_substr(s1, 0, len);
	return (str);
}
