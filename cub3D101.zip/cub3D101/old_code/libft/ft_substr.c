/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nettalha <nettalha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/05 15:20:27 by nettalha          #+#    #+#             */
/*   Updated: 2023/08/31 11:33:50 by nettalha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_substr(char const *s, unsigned int start, int len)
{
	char	*str;
	int		i;

	if (!s)
		return (NULL);
	if (len < ft_strlen(s))
		str = malloc(sizeof(char) * len + 1);
	else
		str = malloc(sizeof(char) * ft_strlen(s) + 1);
	if (!str)
		return (NULL);
	i = 0;
	while (start < (unsigned int)ft_strlen(s) 
		&& ((char *)s)[start] != '\0' && i < len)
	{
		str[i] = ((char *)s)[start];
		start++;
		i++;
	}
	str[i] = '\0';
	return (str);
}
