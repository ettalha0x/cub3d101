/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_map_in.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nettalha <nettalha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/12 11:22:19 by nettalha          #+#    #+#             */
/*   Updated: 2023/08/17 10:05:19 by nettalha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

int	check_map_in(t_game *g)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (g->map[i])
	{
		j = 0;
		while (g->map[i][j])
		{
			if (g->map[i][j] != '0' && g->map[i][j] != '1'
				&& g->map[i][j] != 'N' && g->map[i][j] != 'S'
				&& g->map[i][j] != 'E' && g->map[i][j] != 'W'
				&& g->map[i][j] != ' ' && g->map[i][j] != '\n')
				return (printf("map_in error !\n"), 0);
			j++;
		}
		i++;
	}
	return (1);
}
