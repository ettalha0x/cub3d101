/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   move_player.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nettalha <nettalha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/25 18:09:38 by nettalha          #+#    #+#             */
/*   Updated: 2023/09/09 11:09:37 by nettalha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	move_u(t_game *game, t_vec v)
{
	if (game->map[(int)((game->player.y - 11 * v.y) / SQUAR_SIZE)][(int)((game->player.x - 11 * v.x) / SQUAR_SIZE)] != '1'
	&& game->map[(int)((game->player.y - 11 * v.y) / SQUAR_SIZE)][(int)((game->player.x) / SQUAR_SIZE)] != '1'
	&& game->map[(int)((game->player.y) / SQUAR_SIZE)][(int)((game->player.x - 11 * v.x) / SQUAR_SIZE)] != '1')
	{
		game->player.x -= 5 * v.x;
		game->player.y -= 5 * v.y;
	}
}

void	move_d(t_game *game, t_vec v)
{
	if (game->map[(int)((game->player.y + 11 * v.y) / SQUAR_SIZE)][(int)((game->player.x + 11 * v.x) / SQUAR_SIZE)] != '1'
		&& game->map[(int)((game->player.y + 11 * v.y) / SQUAR_SIZE)][(int)((game->player.x) / SQUAR_SIZE)] != '1'
		&& game->map[(int)((game->player.y) / SQUAR_SIZE)][(int)((game->player.x + 11 * v.x) / SQUAR_SIZE)] != '1')
	{
		game->player.x += 5 * v.x;
		game->player.y += 5 * v.y;
	}
}

void	move_r(t_game *game, t_vec v)
{
	if (game->map[(int)((game->player.y - 11 * v.x) / SQUAR_SIZE)][(int)((game->player.x + 11 * v.y) / SQUAR_SIZE)] != '1'
		&& game->map[(int)((game->player.y - 11 * v.x) / SQUAR_SIZE)][(int)((game->player.x) / SQUAR_SIZE)] != '1'
		&& game->map[(int)((game->player.y) / SQUAR_SIZE)][(int)((game->player.x + 11 * v.y) / SQUAR_SIZE)] != '1')
	{
		game->player.x += 5 * v.y;
		game->player.y -= 5 * v.x;
	}
}

void	move_l(t_game *game, t_vec v)
{
	if (game->map[(int)((game->player.y + 11 * v.x) / SQUAR_SIZE)][(int)((game->player.x - 11 * v.y) / SQUAR_SIZE)] != '1'
		&& game->map[(int)((game->player.y + 11 * v.x) / SQUAR_SIZE)][(int)((game->player.x) / SQUAR_SIZE)] != '1'
		&& game->map[(int)((game->player.y) / SQUAR_SIZE)][(int)((game->player.x - 11 * v.y) / SQUAR_SIZE)] != '1')
	{
		game->player.x -= 5 * v.y;
		game->player.y += 5 * v.x;
	}
}

void	move_player(t_game *game)
{
	t_vec	v;

	v.x = cos(game->angle * (M_PI / 180));
	v.y = sin(game->angle * (M_PI / 180));

	if(mlx_is_key_down(game->mlx, MLX_KEY_W))
	{
		move_u(game, v);
		ft_rebuild(game);
	}
	if (mlx_is_key_down(game->mlx, MLX_KEY_S))
	{
		move_d(game, v);
		ft_rebuild(game);
	}
	if (mlx_is_key_down(game->mlx, MLX_KEY_D))
	{
		move_r(game, v);
		ft_rebuild(game);
	}
	if (mlx_is_key_down(game->mlx, MLX_KEY_A))
	{
		move_l(game, v);
		ft_rebuild(game);
	}
	if (mlx_is_key_down(game->mlx, MLX_KEY_ESCAPE))
		close_win(game);
	if (mlx_is_key_down(game->mlx, MLX_KEY_RIGHT))
	{		
		game->angle += 3;
		if (game->angle > 360)
			game->angle = 0;
		printf("angle = |%f|\n", game->angle);
		ft_rebuild(game);
	}
	if (mlx_is_key_down(game->mlx, MLX_KEY_LEFT))
	{
		game->angle -= 3;
		if (game->angle < 0)
			game->angle = 360;
		printf("angle = |%f|\n", game->angle);
		ft_rebuild(game);
	}
}
