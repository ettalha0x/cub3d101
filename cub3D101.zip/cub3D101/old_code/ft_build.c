/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_build.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: okamili <okamili@student.1337.ma>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/19 13:16:55 by nettalha          #+#    #+#             */
/*   Updated: 2023/09/10 15:36:00 by okamili          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

int get_rgba(int r, int g, int b)
{
    return (r << 24 | g << 16 | b << 8 | 0x000000FF);
}

t_vec	get_Intersections(t_game *g, t_vec wallHit)
{
	t_vec	intercept;
	t_vec	step;


	////////////////////////////////////////////////////////////////////////
	////////////////////////Horizontal Intersection ////////////////////////
	////////////////////////////////////////////////////////////////////////

	
	t_vec	nextHorzTouch;
	t_vec	horzWallHit;
	float	foundHorzWallHit;

	float	isRayFacingDown = g->angle > 0 && g->angle < M_PI;
	float	isRayFacingUp = !isRayFacingDown;
	float	isRayFacingRight = g->angle < (0.5 * M_PI) || g->angle > (1.5 * M_PI);
	float	isRayFacingLeft = !isRayFacingRight;
	g->angle = g->angle * (M_PI / 180);
	horzWallHit.x = 0;
	horzWallHit.y = 0;
	foundHorzWallHit = false;
		
	// find the x,y of the closest horizontal grid intersection
	intercept.y = floor(g->player.y / SQUAR_SIZE) * SQUAR_SIZE;
	if (isRayFacingDown)
		intercept.y += SQUAR_SIZE;
	
	intercept.x = g->player.x + (intercept.y - g->player.y) / tan(g->vue_angle);
	// calculate the increment step.x and step.y
	step.y = SQUAR_SIZE;
	if (isRayFacingUp)
		step.y *= -1;
	else
		step.y *= 1;
	step.x = SQUAR_SIZE / tan(g->vue_angle);
	if (isRayFacingLeft && step.x > 0)
		step.x *= -1;
	else
		step.x *= 1;
	if (isRayFacingRight && step.x < 0)
		step.x *= -1;
	else
		step.x *= 1;
	nextHorzTouch.x = intercept.x;
	nextHorzTouch.y = intercept.y;
	if (isRayFacingUp)
		nextHorzTouch.y--;
	// increment step.x and step.y unitil we find a wall

	while (1)
	{
		if (g->map[(int)nextHorzTouch.y / SQUAR_SIZE][(int)nextHorzTouch.x / SQUAR_SIZE] == '1')
		{
			horzWallHit.x = nextHorzTouch.x;
			horzWallHit.y = nextHorzTouch.y;
			foundHorzWallHit = true;
			break;
		}
		nextHorzTouch.x += step.x;
		nextHorzTouch.y += step.y;
	}
	
	////////////////////////////////////////////////////////////////////////
	////////////////////////Vertical Intersection //////////////////////////
	////////////////////////////////////////////////////////////////////////
	
	t_vec	nextVertTouch;
	t_vec	vertWallHit;
	float	foundVertWallHit;

	vertWallHit.x = 0;
	vertWallHit.y = 0;
	foundVertWallHit = false;
		
	// find the x,y of the closest vertical grid intersection
	intercept.x = floor(g->player.x / SQUAR_SIZE) * SQUAR_SIZE;
	if (isRayFacingRight)
		intercept.x += SQUAR_SIZE;
	intercept.y = g->player.y + (intercept.x - g->player.x) * tan(g->vue_angle);
	
	// calculate the increment step.x and step.y
	step.x = SQUAR_SIZE;
	if (isRayFacingLeft)
		step.x *= -1;
	else
		step.x *= 1;
	step.y = SQUAR_SIZE * tan(g->vue_angle);
	if (isRayFacingUp && step.y > 0)
		step.y *= -1;
	else
		step.y *= 1;
	if (isRayFacingDown && step.y < 0)
		step.y *= -1;
	else
		step.y *= 1;
	nextVertTouch.x = intercept.x;
	nextVertTouch.y = intercept.y;
	if (isRayFacingLeft)
		nextVertTouch.x--;
	// increment step.x and step.y unitil we find a wall

	while (1)
	{
		if (g->map[(int)nextVertTouch.y / SQUAR_SIZE][(int)nextVertTouch.x / SQUAR_SIZE] == '1')
		{
			vertWallHit.x = nextVertTouch.x;
			vertWallHit.y = nextVertTouch.y;
			foundVertWallHit = true;
			break;
		}
		nextVertTouch.x += step.x;
		nextVertTouch.y += step.y;
	}

	// calculate both vertical and horizontal distances and choose the smallest

	float horzDistance;
	float vertDistance;
	
	if(foundHorzWallHit)
		horzDistance = get_distance(g->player, horzWallHit);
	else
		horzDistance = INT8_MAX;
	if(foundVertWallHit)
		vertDistance = get_distance(g->player, vertWallHit);
	else
		vertDistance = INT8_MAX;
	if(horzDistance < vertDistance)
		wallHit.x = horzWallHit.x;
	else
		wallHit.x = vertWallHit.x;
	if(horzDistance < vertDistance)
		wallHit.y = horzWallHit.y;
	else
		wallHit.y = vertWallHit.y;
	return wallHit;	
}

float	get_ray_distance(t_game *g, t_vec p1, t_vec p2)
{
	int		i;
	t_vec	v;
	t_vec	d;
	float	dis;
	float	step;
	float	distance;

	d.x = p1.x - p2.x;
	d.y = p1.y - p2.y;
	
	if (fabs(d.y) > fabs(d.x))
	{
		dis = d.x / d.y;
		step = fabs(d.y);
	}
	else
	{
		dis = d.y / d.x;
		step = fabs(d.x);
	}
    v.x = p1.x;
	v.y = p1.y;
	i = 0;
    while (i < step)
    {
		if(((v.y/SQUAR_SIZE) > 0 && (v.x/SQUAR_SIZE) > 0
			&& g->map[(int)(v.y/SQUAR_SIZE)][(int)(v.x/SQUAR_SIZE)] == '1')
			|| g->map[(int)(v.y/SQUAR_SIZE)][(int)(v.x/SQUAR_SIZE)] == ' ')
			break;
		v.y += d.y / step;
		v.x += d.x / step;
		if ((g->map[(int)((v.y + d.y / step)/SQUAR_SIZE)][(int)(v.x/SQUAR_SIZE)] == '1'
			&& g->map[(int)(v.y/SQUAR_SIZE)][(int)((v.x + d.x / step)/SQUAR_SIZE)] == '1'))
			break;
		i++;
	}
	distance = sqrt(pow(v.x - g->player.x, 2) + pow(v.y - g->player.y, 2));
	return (distance);
}

void	draw_line(t_game *g, t_vec p1, t_vec p2, int color)
{
	int		i;
	t_vec	v;
	t_vec	d;
	float	dis;
	float	step;

	d.x = p1.x - p2.x;
	d.y = p1.y - p2.y;
	
	if (fabs(d.y) > fabs(d.x))
	{
		dis = d.x / d.y;
		step = fabs(d.y);
	}
	else
	{
		dis = d.y / d.x;
		step = fabs(d.x);
	}
    v.x = p1.x;
	v.y = p1.y;
	i = 0;
    while (i < step)
    {
		if (v.x > 0  && v.x < g->map_w && v.y > 0 && v.y < g->map_h)
        	mlx_put_pixel(g->img, (int)v.x * MIN, (int)v.y * MIN, color);
		if(((v.y/SQUAR_SIZE) > 0 && (v.x/SQUAR_SIZE) > 0
			&& g->map[(int)(v.y/SQUAR_SIZE)][(int)(v.x/SQUAR_SIZE)] == '1')
			|| g->map[(int)(v.y/SQUAR_SIZE)][(int)(v.x/SQUAR_SIZE)] == ' ')
			break;
		v.y += d.y / step;
		v.x += d.x / step;
		if ((g->map[(int)((v.y + d.y / step)/SQUAR_SIZE)][(int)(v.x/SQUAR_SIZE)] == '1'
			&& g->map[(int)(v.y/SQUAR_SIZE)][(int)((v.x + d.x / step)/SQUAR_SIZE)] == '1'))
			break;
		i++;
	}
}

void draw_SkyAndFloor(t_game *g)
{
	int	i;
	int	j;

	i = -1;
    while (++i < g->map_h)
    {
		j = -1;
        while (++j < g->map_w)
        {
			if(i > g->map_h / 2)
            	mlx_put_pixel(g->img, j, i, get_rgba(32, 32, 32));
			else
				mlx_put_pixel(g->img, j, i, get_rgba(70, 70, 120));
        }
    }
}

void draw_column(t_game *g, t_vec p, float height)
{
	int	row;
	int	column;

	row = p.y;
	while (row < (p.y + height))
	{
		column = p.x;
		while (column < p.x + 1)
		{
			if (column >= 0 && column < g->map_w && row >= 0 && row < g->map_h)
				mlx_put_pixel(g->img, column, row, get_rgba(255, 0, 0));
			column++;
		}
		row++;
	}
}

void	draw_3d_wall(t_game *g, float distance, int i)
{
	t_vec	p;

	p.x = i;
	p.y = ((g->map_h / 2) - (((g->map_h / 2) * SQUAR_SIZE) / distance));
	draw_column(g, p, g->map_h - (p.y * 2));
}

void	draw_fov(t_game *g, t_vec p1, t_vec p2)
{
	int		i;
	float	distance;
	
	i = 0;
	g->vue_angle = (g->angle - 30) * (M_PI / 180);
	draw_SkyAndFloor(g);
	while (i < g->map_w)
	{
		p1.x = g->player.x;
		p1.y = g->player.y;
		p2.x = p1.x + cos(g->vue_angle) * g->map_w;	
		p2.y = p1.y + sin(g->vue_angle) * g->map_w;
		distance = get_ray_distance(g, p1, p2);
		distance = distance * cos(g->vue_angle - (g->angle * (M_PI / 180)));
		draw_3d_wall(g, distance, i);
		g->vue_angle += ((60  * (M_PI / 180)) / g->map_w);
		i++;
	}
	printf("dis: %f\n", distance);
	printf("number of rays: %d\n", i);
}

void	draw_vue_angle(t_game *g, t_vec p1, t_vec p2)
{
	int		i;
	
	i = 0;
	g->vue_angle = (g->angle + 30) * (M_PI / 180);
	while (i < g->map_w)
	{
		p1.x = g->player.x;
		p1.y = g->player.y;
		p2.x = p1.x + cos(g->vue_angle) * g->map_w;	
		p2.y = p1.y + sin(g->vue_angle) * g->map_w;
		draw_line(g, p1, p2, get_rgba(255, 255, 255));
		g->vue_angle -= ((60  * (M_PI / 180)) / g->map_w);
		i++;
	}
}

void	draw_back(t_game *g)
{
	int i = 0;
	while (i < g->map_w)
	{
		int j = 0;
		while (j < g->map_h)
		{
			mlx_put_pixel(g->img, i * MIN, j * MIN, 0x9ACD32);
			j++;
		}
		i++;
	}
}

void	draw_space(t_game *g, int x, int y)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (i < SQUAR_SIZE)
	{
		j = 0;
		while (j < SQUAR_SIZE)
		{
			mlx_put_pixel(g->img, (j + x) * MIN, (i + y) * MIN, get_rgba(91, 191, 31));
			j++;
		}
		i++;
	}
}

void	draw_wall(t_game *g, int x, int y)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (i < SQUAR_SIZE)
	{
		j = 0;
		while (j < SQUAR_SIZE)
		{
			mlx_put_pixel(g->img, (j + x) * MIN, (i + y) * MIN, get_rgba(75, 155, 233));
			j++;
		}
		i++;
	}
}

void	draw_grid(t_game *g)
{
	int i = 0;
	while (i < g->map_w)
	{
		int j = 0;
		while (j < g->map_h)
		{
			if((i % SQUAR_SIZE == 0 || j % SQUAR_SIZE == 0))
				mlx_put_pixel(g->img, i * MIN, j * MIN, get_rgba(241, 191, 72));
			j++;
		}
		i++;
	}
}
void draw_player(t_game *g, int x, int y)
{
	int	r;

	r = SQUAR_SIZE / 10;
    int i = -r;
    while (i <= r)
    {
        int j = -r;
        while (j <= r)
        {
            if ((i * i) + (j * j) <= (r * r) && (x + i) > 0 && (x + i) < g->map_w && (y + j) > 0 && (y + j < g->map_h))
			{
				mlx_put_pixel(g->img, (x + i) * MIN, (y + j) * MIN, get_rgba(255, 255, 255));
			}
            j++;
        }
        i++;
    }
}

void	find_player(t_game *g, t_vec p1, t_vec p2)
{
	int	i;
	int	j;
	
	i = 0;
	while (g->map[i])
	{
		j = 0;
		while (g->map[i][j])
		{
			if (g->map[i][j] == 'N' || g->map[i][j] == 'E' || g->map[i][j] == 'S' || g->map[i][j] == 'W')
			{
				g->map[i][j] = '0';
				g->angle = 0;
				p1.x = (j * SQUAR_SIZE);
				p1.y = (i * SQUAR_SIZE);
				p2.x = p1.x + cos(g->angle * (M_PI / 180)) * SQUAR_SIZE;
				p2.y = p1.y + sin(g->angle * (M_PI / 180)) * SQUAR_SIZE;
				g->player.x = p1.x;
				g->player.y = p1.y;
				return ;
			}
			j++;
		}
		i++;
	}
}
void	ft_build(t_game *g)
{
	int	i;
	int	j;
	t_vec	p1;
	t_vec	p2;
	
	
	i = 0;
	p1.x = 0;
	p1.y = 0;
	p2.x = 0;
	p2.y = 0;
	find_player(g, p1, p2);
	draw_fov(g, p1, p1);
	draw_back(g);
	while (g->map[i])
	{
		j = 0;
		while (g->map[i][j])
		{
			if (g->map[i][j] == '1')
				draw_wall(g, j * SQUAR_SIZE, i * SQUAR_SIZE);
			else if (g->map[i][j] == '0')
				draw_space(g, j * SQUAR_SIZE, i * SQUAR_SIZE);
			j++;
		}
		i++;
	}
	draw_grid(g);
	draw_player(g, g->player.x, g->player.y);
	draw_vue_angle(g, p1, p2);
	draw_line(g, p1, p2, get_rgba(41, 71, 81));
}

void	ft_rebuild(t_game *g)
{
	int	i;
	int	j;
	t_vec	p1;
	t_vec	p2;
	
	i = 0;
	p1.x = g->player.x;
	p1.y = g->player.y;
	p2.x = p1.x + cos(g->angle * (M_PI / 180)) * SQUAR_SIZE;
	p2.y = p1.y + sin(g->angle * (M_PI / 180)) * SQUAR_SIZE;
	draw_fov(g, p1, p2);
	draw_back(g);
	while (g->map[i])
	{
		j = 0;
		while (g->map[i][j])
		{
			if(g->map[i][j] == '1')
				draw_wall(g, j * SQUAR_SIZE, i * SQUAR_SIZE);
			else if(g->map[i][j] == '0' || g->map[i][j] == 'X' || g->map[i][j] == 'N' || g->map[i][j] == 'E' || g->map[i][j] == 'S' || g->map[i][j] == 'W')
				draw_space(g, j * SQUAR_SIZE, i * SQUAR_SIZE);
			j++;
		}
		i++;
	}
	draw_grid(g);
	draw_player(g, g->player.x, g->player.y);
	draw_vue_angle(g, p1, p2);
	draw_line(g, p1, p2, get_rgba(41, 71, 81));
}
