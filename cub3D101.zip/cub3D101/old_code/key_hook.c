/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   key_hook.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nettalha <nettalha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/19 16:40:20 by nettalha          #+#    #+#             */
/*   Updated: 2023/09/04 15:59:36 by nettalha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	key_hook(void *void_game)
{
	t_game *game;

	game = (t_game*)void_game;
	move_player(game);
}

int	close_win(t_game *game)
{
	printf("you quite the game\n");
	ft_exit(game);
	return (0);
}
