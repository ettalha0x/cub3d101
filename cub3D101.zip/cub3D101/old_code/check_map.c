/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_map.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nettalha <nettalha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/12 11:22:45 by nettalha          #+#    #+#             */
/*   Updated: 2023/08/27 19:36:03 by nettalha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

int	check_map(t_game *g)
{
	int i;
	int j;
	int	len;
	int	height;

	height = count_map_lines(g->map);
	i = -1;
	while (g->map[++i])
	{
		j = -1;
		len = ft_strlen(g->map[i]);
		while (g->map[i][++j])
		{
			if (g->map[i][j] == '0')
			{
				if (i == 0 || j == 0 || i == height - 1 || j == len - 1)
				{
					printf("error here (%d, %d)\n", i, j);
					return (printf("border error 1\n"), 0);
				}
				else if (g->map[i + 1][j] == ' ' || g->map[i - 1][j] == ' ' || g->map[i][j + 1] == ' ' || g->map[i][j - 1] == ' ')
				{
					printf("error here (%d, %d)\n", i, j);
					return (printf("inside error 2\n"), 0);
				}
			}
		}
	}
	return (1);
}
