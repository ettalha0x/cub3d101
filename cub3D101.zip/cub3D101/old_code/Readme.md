# Cub3D

This project is written in c using mini-libx Library, This old library has a little builtin-funcs.


## Project Roadmap

- [x]   map parsing.
- [x]   map drawing.
- [x]   player movement.
- [x]   vue angle drawing.
- [x]   prevent player from getting outside.
- [x]   prevent rays from getting outside.
- [x]   raycasting.
- [x]   wall projection.
- [x]   sky and floor drawing.
- [ ]   draw textures.
- [ ]   refactoring.
- [ ]   optimization.


## Authors

- Oussama Kamili [@oussamakami](https://github.com/oussamakami)

- Noureddine Ettalhaouy [@ettalha0x](https://github.com/ettalha0x)