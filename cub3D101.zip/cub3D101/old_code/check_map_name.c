/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_map_name.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nettalha <nettalha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/30 20:38:01 by nettalha          #+#    #+#             */
/*   Updated: 2023/08/17 10:05:19 by nettalha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

int	check_map_name(char *name)
{
	char	*arr;
	int		i;
	int		j;

	arr = ".cub";
	j = 3;
	i = ft_strlen(name) - 1;
	while (j >= 0)
	{
		if (name[i] != arr[j])
		{
			printf("Error!\n");
			return (0);
		}
		j--;
	i--;
	}
	return (1);
}
